from setuptools import setup, find_packages

setup(
    name='text_mods',
    version='1.1',
    packages=find_packages(),
)