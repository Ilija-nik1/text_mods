from setuptools import setup, find_packages

setup(
    name='text_mods',
    version='1.41',
    packages=find_packages(),
)